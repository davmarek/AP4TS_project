# What was done?
- hierarchy
- test cases
  - Home_Page/HP_001
  - Home_Page/Hero_Section/HR_001
  - Home_Page/Hero_Section/HR_002
  - Home_Page/A_Team_Section/HA_001
  - Home_Page/A_Team_Section/HA_002
  - Home_Page/A_Team_Section/HA_003
  - Home_Page/A_Team_Section/HA_004
- (suite/folder) structure

> Most of the folders are empty, just prepared.